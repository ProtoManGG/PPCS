package com.pranavtaneja.getx_ecosystem_trial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
