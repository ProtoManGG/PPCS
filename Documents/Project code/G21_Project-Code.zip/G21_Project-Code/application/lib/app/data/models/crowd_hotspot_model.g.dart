// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crowd_hotspot_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_CrowdHostpotModel _$_$_CrowdHostpotModelFromJson(Map<String, dynamic> json) {
  return _$_CrowdHostpotModel(
    lat: (json['lat'] as num).toDouble(),
    long: (json['long'] as num).toDouble(),
  );
}

Map<String, dynamic> _$_$_CrowdHostpotModelToJson(
        _$_CrowdHostpotModel instance) =>
    <String, dynamic>{
      'lat': instance.lat,
      'long': instance.long,
    };
