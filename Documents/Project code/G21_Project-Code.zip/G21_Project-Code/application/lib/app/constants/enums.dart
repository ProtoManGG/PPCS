enum AppState { initial, loading, loaded, failure }
