String? baseUrl = "http://18.219.3.66:8000";
const kGoogleApiKey = "AIzaSyC65uWOQsZSDpSfeDyKLIYWorwADgRu5RU";
